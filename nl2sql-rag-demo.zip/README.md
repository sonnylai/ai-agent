# Empty Project Workspace

This workspace was initialized as an empty project. You can start adding your own files and structure as needed.
